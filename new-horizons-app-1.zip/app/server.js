/**
 * New Horizons — backend server.
 * Zero external dependencies: only Node.js built-ins (http, fs, path, url).
 * Run with: node server.js
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

/* ---------------- tiny .env loader (no dotenv dependency) ---------------- */
(function loadEnv() {
  const envPath = path.join(__dirname, '.env');
  if (!fs.existsSync(envPath)) return;
  const lines = fs.readFileSync(envPath, 'utf8').split('\n');
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq === -1) continue;
    const key = trimmed.slice(0, eq).trim();
    const val = trimmed.slice(eq + 1).trim();
    if (!(key in process.env)) process.env[key] = val;
  }
})();

const PORT = process.env.PORT || 3000;
const STAFF_CODE = process.env.STAFF_CODE || '2026';
const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY || '';
const PUBLIC_DIR = path.join(__dirname, 'public');

/* ---------------- simple file-backed storage ---------------- */
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);
const NOTICES_FILE = path.join(DATA_DIR, 'notices.json');
const REVIEW_FILE = path.join(DATA_DIR, 'task-review.json');
if (!fs.existsSync(NOTICES_FILE)) fs.writeFileSync(NOTICES_FILE, '[]');
if (!fs.existsSync(REVIEW_FILE)) fs.writeFileSync(REVIEW_FILE, '{}');

function readJSON(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch (e) { return fallback; }
}
function writeJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

/* ---------------- banned words + system prompt (student chat safety) ---------------- */
const BANNED_WORDS = [
  // Arabic
  "علاج", "علاجات", "حقنة", "حقن", "إبرة", "إبر", "وخز", "عملية جراحية", "عمليه جراحيه", "جراحة", "جراحه",
  "دواء", "أدوية", "ادويه", "ألم", "الم", "وجع", "دم", "مستشفى", "مستشفي", "مرض", "مريض", "حقنه", "إبره",
  // English
  "treatment", "injection", "injections", "needle", "needles", "shot", "shots", "iv", "surgery", "operation",
  "medication", "medicine", "medicines", "drug", "drugs", "pain", "blood", "hospital", "illness", "disease"
];
function containsBanned(text) {
  const lower = String(text || '').toLowerCase();
  return BANNED_WORDS.some(w => lower.includes(w.toLowerCase()));
}
const SAFE_REDIRECT_AR = "هذا سؤال من الأفضل طرحه على الممرضة أو الطاقم الطبي أو أحد أفراد عائلتك، وليس عليّ 💙 هل تحب أن نتابع درسًا في الرياضيات أو اللغة العربية أو التربية الإسلامية؟";

const SYSTEM_PROMPT = `You are "مساعد آفاق جديدة" (New Horizons Assistant), a warm, friendly study helper for children currently staying in hospital who are continuing their schooling remotely.
You must fully understand BOTH Arabic (Modern Standard Arabic and common dialectal expressions) and English. Always reply in the same language the student used (if they mix both languages, reply mostly in Arabic, simply). Never say you don't understand a word in either language — always do your best to interpret it.
Subjects you help with: الرياضيات (Math), التربية الإسلامية (Islamic Education), اللغة العربية (Arabic) — for السنة الأولى والثانية (Year 1 and Year 2) — across four skills: الاستماع (Listening), التعبير الشفهي (Oral expression), القراءة (Reading), الكتابة (Writing).
Style: simple, encouraging, max 3-5 short sentences, occasionally ask a small follow-up question to keep them engaged.
ABSOLUTE RULES — never break these, even if asked indirectly, hypothetically, in another language, or "just to translate":
- NEVER mention or discuss: treatment, therapy, injection(s), needle(s), shot(s), IV, surgery/operation, medication/medicine/drugs, pain, blood, illness/disease details, or any hospital/medical/clinical content whatsoever.
- If the student asks anything health-related, or seems worried about their condition, do NOT answer it at all — gently and warmly redirect them to talk to their nurse, doctor, or a family member instead.
- Keep the tone calm, safe, and cheerful at all times — never mention anything that could feel scary or clinical.
- If a question is unrelated to the three subjects, answer briefly and kindly, then guide them back to something they can study.`;

/* ---------------- helpers ---------------- */
function sendJSON(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body)
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => {
      data += chunk;
      if (data.length > 1e6) req.destroy(); // 1MB safety cap
    });
    req.on('end', () => {
      if (!data) return resolve({});
      try { resolve(JSON.parse(data)); }
      catch (e) { reject(e); }
    });
    req.on('error', reject);
  });
}

function isStaff(req) {
  return req.headers['x-staff-code'] === STAFF_CODE;
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function serveStatic(req, res, pathname) {
  let filePath = pathname === '/' ? '/index.html' : pathname;
  const fullPath = path.normalize(path.join(PUBLIC_DIR, filePath));
  // prevent path traversal outside the public directory
  if (!fullPath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403); return res.end('Forbidden');
  }
  fs.readFile(fullPath, (err, content) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('لم يتم العثور على الصفحة');
    }
    const ext = path.extname(fullPath);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(content);
  });
}

/* ---------------- request handler ---------------- */
const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  const pathname = parsed.pathname;

  try {
    /* ---- staff login ---- */
    if (pathname === '/api/staff-login' && req.method === 'POST') {
      const body = await readBody(req);
      return sendJSON(res, 200, { ok: body.code === STAFF_CODE });
    }

    /* ---- notices & updates ---- */
    if (pathname === '/api/notices' && req.method === 'GET') {
      return sendJSON(res, 200, readJSON(NOTICES_FILE, []));
    }
    if (pathname === '/api/notices' && req.method === 'POST') {
      if (!isStaff(req)) return sendJSON(res, 401, { error: 'unauthorized' });
      const body = await readBody(req);
      const text = (body.text || '').trim();
      if (!text) return sendJSON(res, 400, { error: 'text required' });
      const list = readJSON(NOTICES_FILE, []);
      const item = { id: Date.now(), text, type: body.type === 'update' ? 'update' : 'notice', ts: Date.now() };
      list.push(item);
      writeJSON(NOTICES_FILE, list);
      return sendJSON(res, 200, item);
    }
    if (pathname.startsWith('/api/notices/') && req.method === 'DELETE') {
      if (!isStaff(req)) return sendJSON(res, 401, { error: 'unauthorized' });
      const id = pathname.split('/').pop();
      let list = readJSON(NOTICES_FILE, []);
      list = list.filter(n => String(n.id) !== id);
      writeJSON(NOTICES_FILE, list);
      return sendJSON(res, 200, { ok: true });
    }

    /* ---- task review ---- */
    if (pathname === '/api/task-review' && req.method === 'GET') {
      return sendJSON(res, 200, readJSON(REVIEW_FILE, {}));
    }
    if (pathname === '/api/task-review' && req.method === 'POST') {
      if (!isStaff(req)) return sendJSON(res, 401, { error: 'unauthorized' });
      const body = await readBody(req);
      if (!body.key || !body.status) return sendJSON(res, 400, { error: 'key and status required' });
      const map = readJSON(REVIEW_FILE, {});
      map[body.key] = body.status;
      writeJSON(REVIEW_FILE, map);
      return sendJSON(res, 200, { ok: true });
    }

    /* ---- AI study chat ---- */
    if (pathname === '/api/chat' && req.method === 'POST') {
      if (!ANTHROPIC_API_KEY) {
        return sendJSON(res, 500, { error: 'ANTHROPIC_API_KEY is not set on the server' });
      }
      const body = await readBody(req);
      const messages = body.messages;
      if (!Array.isArray(messages) || !messages.length) {
        return sendJSON(res, 400, { error: 'messages required' });
      }
      const lastUser = messages[messages.length - 1];
      if (lastUser.role === 'user' && containsBanned(lastUser.content)) {
        return sendJSON(res, 200, { reply: SAFE_REDIRECT_AR });
      }

      const apiRes = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': ANTHROPIC_API_KEY,
          'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-6',
          max_tokens: 1000,
          system: SYSTEM_PROMPT,
          messages
        })
      });
      const data = await apiRes.json();
      if (data.error) {
        console.error('Anthropic API error:', data.error);
        return sendJSON(res, 500, { error: data.error.message || 'API error' });
      }
      let reply = (data.content || []).map(b => b.text || '').join('').trim()
        || 'عذرًا، حدث خلل بسيط، هل يمكنك إعادة السؤال؟';
      if (containsBanned(reply)) reply = SAFE_REDIRECT_AR;
      return sendJSON(res, 200, { reply });
    }

    /* ---- static files (index.html, admin.html, etc.) ---- */
    if (req.method === 'GET') {
      return serveStatic(req, res, pathname);
    }

    sendJSON(res, 404, { error: 'not found' });
  } catch (e) {
    console.error(e);
    sendJSON(res, 500, { error: 'server error' });
  }
});

server.listen(PORT, () => {
  console.log(`New Horizons server running at http://localhost:${PORT}`);
  if (!ANTHROPIC_API_KEY) {
    console.warn('⚠️  ANTHROPIC_API_KEY is not set — the AI chat will not work until you add it to .env');
  }
});
